from django.urls import path

urlpatterns = [
    # Routes for $app
]
